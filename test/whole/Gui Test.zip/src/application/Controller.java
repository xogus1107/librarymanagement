package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller {
	
	public static ArrayList<User> userlist = new ArrayList<>();
	public static ArrayList<Book> booklist = new ArrayList<>();
	@FXML
	private TextField txtUserName;
	@FXML
	private PasswordField txtPassword;

	
	
	public Controller() throws NumberFormatException, IOException {
		BufferedReader bufferUser = new BufferedReader(new FileReader("user.txt"));
		BufferedReader bufferBook = new BufferedReader(new FileReader("book.txt"));
		String s;
		while ((s = bufferUser.readLine()) != null) {
			String[] split = s.split(" ");
			userlist.add(new User(split[0], split[1], split[2], split[3], split[4], Integer.valueOf(split[5]),
					Integer.valueOf(split[6]), Integer.valueOf(split[7]), Long.valueOf(split[8]),
					Long.valueOf(split[9]), Long.valueOf(split[10]), Long.valueOf(split[11]), Long.valueOf(split[12]),
					Long.valueOf(split[13])));
		}
		bufferUser.close();
		bufferBook.close();
	}
	

	
	
	

	public void Login(ActionEvent event) throws Exception {
		

		if (txtUserName.getText().equals("admin") && txtPassword.getText().equals("12345")) {
			
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.show();


		}
		for (int i = 0; i < userlist.size(); i++) {
			if (txtUserName.getText().equals(userlist.get(i).getID())
					&& txtPassword.getText().equals(userlist.get(i).getPW())) {
				Stage primaryStage = new Stage();
				Parent root = FXMLLoader.load(getClass().getResource("User.fxml"));
				Scene scene = new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.show();

			}

		}

	}

}
